import React from 'react'
import { Login } from '../components';
function Login() {
  return (
    <div className='py-8'>
        <Login />
    </div>
  )
}

export default Login